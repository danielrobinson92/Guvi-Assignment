/*----------------3. Write a “person” class to hold all the details. -----------------*/

class Person {
    constructor(name, age, country, degree) {
        this.name = name;
        this.age = age;
        this.country = country;
        this.degree = degree;
    }
}
let daniel = new Person("Daniel", 28, "India", "BCA");
let robinson = new Person("Robinson", 28, "India", "MBA");
console.log(daniel);
console.log(robinson);

// /*-----------------4. write a class to calculate uber price---------------------*/
class Uber {
    constructor(passengername, cartype, distance) {
        this.passengername = passengername;
        this.cartype = cartype;
        this.distance = distance;
    }
}

let price = (uber) => uber.cartype == "Sedan" ? uber.distance*5 : uber.cartype == "Mini" ? uber.distance * 2 : uber.cartype == "SUV" ? uber.distance * 10 : "Trip not Found";
let trip1 = new Uber("Daniel", "Sedan", 40);
let trip2 = new Uber("Robinon", "Mini", 40);
let trip3 = new Uber("Blessy", "SUV", 40);

console.log(`Uber Price for Passenger ${trip1.passengername} : `,price(trip1));
console.log(`Uber Price for Passenger ${trip2.passengername} : `,price(trip2));
console.log(`Uber Price for Passenger ${trip3.passengername} : `,price(trip3));
